

a = [1,2,3,4]

for i in range(2):
    for j in a:
        if j == 2:
            a.remove(j)