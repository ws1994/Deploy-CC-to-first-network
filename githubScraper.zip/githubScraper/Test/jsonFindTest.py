'''
Author: Netzhang
Descripttion: 
version: 
Date: 2020-08-05 01:05:40
LastEditors: Netzhang
LastEditTime: 2020-08-07 15:35:01
'''
import sys
sys.path.append("..")

import json
from pathlib import Path
import yaml

fileName = "D:\\师兄项目\\githubScraper\\data\\repo\\sunwoo2\\Hyperledger-Fabric\\Hyperledger-Fabric-master\\fabric-samples\\balance-transfer\\artifacts\\channel\\configtx.yaml"
print(fileName)
with open(fileName,'r',encoding='utf-8') as f:
    Application = False
    Endorsement = False
    EndorsementType = ""
    EndorsementRule = ""
    res = yaml.load(f,Loader=yaml.FullLoader)
    if "Application" in res:
        Application = True
        if "Policies" in res["Application"]:
            if "Endorsement" in res["Application"]["Policies"]:
                Endorsement = True
                print(res["Application"]["Policies"]["Endorsement"])
                if "Type" in res["Application"]["Policies"]["Endorsement"]:
                    EndorsementType = res["Application"]["Policies"]["Endorsement"]["Type"]
                if "Rule" in res["Application"]["Policies"]["Endorsement"]:
                    EndorsementRule = res["Application"]["Policies"]["Endorsement"]["Rule"]
    print("EndorsementType:{}".format(EndorsementType))
    print("EndorsementRule:{}".format(EndorsementRule))
