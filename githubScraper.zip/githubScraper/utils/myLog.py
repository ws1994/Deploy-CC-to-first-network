# encoding:utf-8
import logging
import sys

class MyLog:
    '''
    封装后的logging
    '''
    def __init__(self, filename = None, loggerName = None):
        '''
        指定保存日志的文件路径，日志级别，以及调用文件
        将日志存入到指定的文件中
        '''
        if not loggerName:
            loggerName = 'default'

        # create a logger
        self.logger = logging.getLogger(loggerName)
        self.filename = filename
        self.logger.setLevel(logging.DEBUG)             # 开发和线上可后续根据配置文件来设置
 
        # create a console handler
        ch = logging.StreamHandler(sys.stderr)
        ch.setLevel(logging.INFO)

        # create a logging format
        formatter = logging.Formatter('[%(asctime)s] %(filename)s->%(funcName)s line:%(lineno)d [%(levelname)s]:%(message)s')
        ch.setFormatter(formatter)
 
        self.logger.addHandler(ch)

        if not filename is None:
            fh = logging.FileHandler(filename, 'a', encoding='utf-8')
            fh.setLevel(logging.INFO)
            fh.setFormatter(formatter)
            self.logger.addHandler(fh)
 
    def getlog(self):
        return self.logger