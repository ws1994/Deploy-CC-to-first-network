'''
Author: Netzhang
Descripttion: 
version: 
Date: 2020-08-05 07:13:23
LastEditors: Netzhang
LastEditTime: 2020-08-05 07:17:40
'''
import sys
sys.path.append("..")

from pathlib import Path
import os 

if __name__ == "__main__":
    path = Path("../data/repo/")

    fileType = '**/*.zip'
    
    all_file = list(path.glob(fileType))

    # print(len(all_file))

    print(all_file)
