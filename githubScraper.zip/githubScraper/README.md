<!--
 * @Author: Netzhang
 * @Descripttion: 
 * @version: 
 * @Date: 2020-08-02 01:52:31
 * @LastEditors: Netzhang
 * @LastEditTime: 2020-08-06 23:22:51
--> 
[TOC]

# Github数据爬取 & 项目分析

## 零：准备工作

- 实验环境：
  - 系统：Windows 10 Pro 
  - 编程语言：python v3.8.4
  - 数据库：mongodb v4.2.6

## 一、Github数据爬取

### 1.1 Repositories统计信息爬取

- 介绍：通过github官方API`https://api.github.com/search/repositories?q=hyperledger `来执行高级条件查询，获取到Github中所有与hyperledger相关的项目统计信息。

- 具体说明：

  - 通过scrapy来爬取 `https://api.github.com/search/repositories?q=hyperledger+created:2013-01 `，其中`created`表示创建的时候，项目中爬取了2013-01-01到2020-08-04期间所有hyperledger项目

  - 数据保存到mongodb数据库中，数据库单条记录信息如下：

    ```javascript
        "_id": ObjectId("5f2972b64f60c9e93083caef"),
        "ID": NumberInt("12001251"),
        "name": "hyperledger-fabric",
        "full_name": "deusimarferreira/hyperledger-fabric",
        "html_url": "https://github.com/deusimarferreira/hyperledger-fabric",
        "description": "Hyperledger Fabric",
        "git_url": "git://github.com/deusimarferreira/hyperledger-fabric.git",
        "ssh_url": "git@github.com:deusimarferreira/hyperledger-fabric.git",
        "stars": NumberInt("0"),
        "forks": NumberInt("0"),
        "watchers": NumberInt("0"),
        "created_at": "2013-08-09T13:16:46Z",
        "updated_at": "2020-05-06T22:00:04Z",
        "pushed_at": "2020-05-13T02:39:06Z",
        "size": NumberInt("42011"),
        "language": "JavaScript",
        "owner_name": "deusimarferreira",
        "default_branch": "master",
        
         // 用于github仓库下载字段
        "is_download": true,
        "save_path": "仓库绝对路径",
         
         // 用于github仓库hyperledger配置检测
        "json_private": true,
        "json_private_path": "json文件绝对路径",
        "explicit_use": true,
    	"explicit_path": "出现endorsementPolicy关键字文件路径”,
        
    	"go_private": true,
        "go_private_path": "go项目使用privateData具体文件路径",
        "java_private": true,
        "java_private_path": "java项目使用privateData具体文件路径",
        "node_private": true,
        "node_private_path": "node项目使用privateData具体文件路径",
        "implicit_use": true,
    	"implicit_path": "出现_implicit_org_关键字文件路径”,
        
    ```

### 1.2 Repositories下载

- 介绍：通过1.1中数据库保存的记录，下载Repositories到本地目录
- 具体说明：
  - 获取数据库`size>0 and is_download=false`的仓库
  - 利用`owner_name`、`name`、`default_branch`字段构造仓库zip文件下载目录，下载链接举例：`https://codeload.github.com/{owner_name}/{name}/zip/{default_branch}`
  - 利用python脚本下载上述链接到本地
  - 解压对应的zip文件，并将解压后的仓库目录保存至数据库`save_path`字段



## 二、项目分析

### 2.1 explicit模式检测

- 介绍：检测hyperledger项目配置文件使用了private data的项目，并检查是否使用了`endorsementPolicy`配置项

- 具体说明：

  - 获取1.1得到的数据库所有记录，根据`save_path`字段获取项目存储路径

  - 检索项目文件夹中所有的`.json`文件路径

  - 对于每个JSON文件，检查是否存在以下字段中，并且不同出现其中至少五个字段，如果满足，则标记为使用了private data的项目，更新数据库中`json_private`、`json_private_path` 字段

    > "name" 、"policy"、"requiredPeerCount"、"maxPeerCount"、"blockToLive"、"memberOnlyRead"

  - 同时对于每个JSON文件，如果已标记使用了private data，需要检测是否存在`endorsementPolicy`关键字，如果满足条件，将项目标记为explicit，更新数据库该记录`explicit_use`、`explicit_path`字段

### 2.2 implicit模式检测

- 介绍：通过检测hyperledger项目文件中使用了private data API的项目，并检查是否使用了`_implicit_org_`参数

- 具体说明：

  - 获取1.1得到的数据库所有记录，根据`save_path`字段获取项目存储路径

  - 检索项目文件夹中所有的`.go`、`.java`、`.js`文件路径

  - 对于每个文件，对于不同的语言文件，检测是否使用了以下API中的任意一种，如果满足，则标记为使用了private data的项目，更新数据库中`go_private`、`go_private_path` 、`java_private`、`java_private_path` 、`node_private`、`node_private_path` 字段

    > // 不同语言private data API
    >
    > go：GetPrivateData 、PutPrivateData、DelPrivateData
    >
    > java：getPrivateData、putPrivateData、delPrivateData
    >
    > node：getPrivateData、putPrivateData、deletePrivateData

  - 同时对于每个文件，如果已标记为使用了private data，检测文件是否出现了`_implicit_org_`关键字，如果满足条件，将项目标记为implicit，更新数据库该记录`implicit_use`、`implicit_path`字段


### 使用
1. `scrapy crawl GithubScraper -a keyword="hyperledger-fabric"`



16年七月之前的项目是什么原因。

fabric项目数多受欢迎。

private data受欢迎程度。

explicit implicit 使用情况。
