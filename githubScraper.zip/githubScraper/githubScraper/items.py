'''
@Author: Netzhang
@Descripttion: 
@version: 
@Date: 2020-08-02 01:51:28
LastEditors: Netzhang
LastEditTime: 2020-08-05 07:38:26
'''
# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy

class RepoItem(scrapy.Item):
    ID = scrapy.Field()
    name = scrapy.Field()
    owner_name = scrapy.Field()
    full_name = scrapy.Field()
    html_url = scrapy.Field()
    description = scrapy.Field()
    git_url = scrapy.Field()
    ssh_url = scrapy.Field()

    stars = scrapy.Field()
    forks = scrapy.Field()
    watchers = scrapy.Field()
    created_at = scrapy.Field()
    updated_at = scrapy.Field()
    pushed_at = scrapy.Field()

    default_branch = scrapy.Field()
    size = scrapy.Field()
    language = scrapy.Field()       # 表示是什么语言