'''
Author: Netzhang
Descripttion: 
version: 
Date: 2020-08-02 01:51:28
LastEditors: Netzhang
LastEditTime: 2020-08-03 00:18:17
'''
# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

import random
import base64
import time

from scrapy import signals
from githubScraper.settings import PROXY_LIST	#请更改项目名
from scrapy.downloadermiddlewares.useragent import UserAgentMiddleware
from scrapy.downloadermiddlewares.retry import RetryMiddleware
from scrapy.utils.response import response_status_message

from fake_useragent import UserAgent

# 随机代理
class RandomProxy(object):
    def process_request(self, request, spider):
        # 随机取出一个代理ip
        proxy = random.choice(PROXY_LIST)

        # 判断是否为人民币玩家
        if proxy['user_passwd'] is not None:
            #把账号密码转换为b64编码格式(字符串先变成bytes类型）必须字符串转为bytes
            b64_data = base64.b64encode(proxy['user_passwd'].encode())
            # 设置账号密码认证                     认证方式   编码之后的账号密码
            request.headers['Proxy-Authorization'] = 'Basic ' + b64_data.decode()
            # 设置代理
        else:
            # 免费代理不用认证
            request.meta['proxy'] = proxy['ip_port']

# 状态429解决办法，延迟重发
class TooManyRequestsRetryMiddleware(RetryMiddleware):
    def __init__(self,crawler):
        super(TooManyRequestsRetryMiddleware, self).__init__(crawler.settings)
        self.crawler = crawler

    @classmethod
    def from_crawler(cls, crawler):
        return cls(crawler)
 
    def process_response(self, request, response, spider):
        if request.meta.get('dont_retry', False):
            return response
        elif response.status == 429: 
            self.crawler.engine.pause()
            print("请求速度过快,出现429状态号,暂停120秒")
            time.sleep(120)  # If the rate limit is renewed in a minute, put 60 seconds, and so on.
            self.crawler.engine.unpause()
            reason = response_status_message(response.status)
            return self._retry(request, reason, spider) or response
        elif response.status in self.retry_http_codes:
            reason = response_status_message(response.status)
            return self._retry(request, reason, spider) or response
        return response