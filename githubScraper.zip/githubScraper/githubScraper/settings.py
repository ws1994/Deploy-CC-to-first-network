'''
@Author: Netzhang
@Descripttion: 
@version: 
@Date: 2020-08-02 01:51:28
LastEditors: Netzhang
LastEditTime: 2020-08-07 15:15:51
'''
# Scrapy settings for githubScraper project
#
# For simplicity, this file contains only settings considered important or
# commonly used. You can find more settings consulting the documentation:
#
#     https://docs.scrapy.org/en/latest/topics/settings.html
#     https://docs.scrapy.org/en/latest/topics/downloader-middleware.html
#     https://docs.scrapy.org/en/latest/topics/spider-middleware.html

# USER_AGENT = 'Netzhang'
USER_AGENT = 'Netzhang'

BOT_NAME = 'githubScraper'
LOG_LEVEL = 'INFO'
DOWNLOAD_HANDLERS = {'s3': None,} # from http://stackoverflow.com/a/31233576/2297751, TODO

RETRY_HTTP_CODES = [500,502,503,504,522,524,408,429,403]
RETRY_TIMES = 60
DOWNLOAD_DELAY = 1
RANDOM_UA_PER_PROXY = True

SPIDER_MODULES = ['githubScraper.spiders']
NEWSPIDER_MODULE = 'githubScraper.spiders'
ITEM_PIPELINES = {
    # 'githubScraper.pipelines.SaveToFilePipeline':100,
    'githubScraper.pipelines.SaveToMongoPipeline':100, # replace `SaveToFilePipeline` with this to use MongoDB
}

# 不使用代理
PROXY_LIST = [
    {'ip_port': 'https://127.0.0.1:12345','user_passwd':None},
]

DOWNLOADER_MIDDLEWARES = {
   #注册ip代理
    'scrapy.downloadermiddleware.useragent.UserAgentMiddleware': None,  #禁用内置的中间件，启用自定义
    'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
    'scrapy_fake_useragent.middleware.RandomUserAgentMiddleware': 400, # 开启
    'scrapy_fake_useragent.middleware.RetryUserAgentMiddleware': 401,
    'githubScraper.middlewares.TooManyRequestsRetryMiddleware': 543,
    'githubScraper.middlewares.RandomProxy': 544                       #请更改项目名
}

# settings for where to save data on disk
SAVE_GITHUB_INFO_PATH = './data/'
SAVE_GITHUB_REP_PATH = './data/rep'

# settings for mongodb
MONGODB_SERVER = "127.0.0.1"
# MONGODB_SERVER = "120.55.170.210"
MONGODB_PORT = 27017
MONGODB_USER = 'root'
MONGODB_PWD = 'Zhangheng11145Q'
MONGODB_DB = "GithubScraper"        # database name to save the crawled data

MONGODB_GITHUB_COLLECTION = "github_info"
MONGODB_GITHUB_FABRIC_COLLECTION = "github_info_fabric"
MONGODB_EXPLICIT_PRIVATE_COLLECTION = "explicit_private"

ROBOTSTXT_OBEY = True
