'''
Author: Netzhang
Descripttion: 
version: 
Date: 2020-08-02 01:51:28
LastEditors: Netzhang
LastEditTime: 2020-08-04 23:41:58
'''
# -*- coding: utf-8 -*-
from scrapy.exceptions import DropItem
from scrapy.utils.project import get_project_settings
import logging
import pymongo
import json
import os

from githubScraper.items import RepoItem
from githubScraper.utils import mkdirs
from scrapy.exporters import JsonItemExporter

SETTINGS = get_project_settings()
print(SETTINGS)

logger = logging.getLogger(__name__)

class SaveToMongoPipeline(object):

    ''' pipeline that save data to mongodb '''
    def __init__(self):
        if SETTINGS['MONGODB_USER']!='' and SETTINGS['MONGODB_USER']!=None:
            url =  'mongodb://{}:{}@{}:{}/'.format(SETTINGS['MONGODB_USER'],SETTINGS['MONGODB_PWD'],SETTINGS['MONGODB_SERVER'],SETTINGS['MONGODB_PORT'])
            connection = pymongo.MongoClient(url)
        else:
            connection = pymongo.MongoClient(SETTINGS['MONGODB_SERVER'], SETTINGS['MONGODB_PORT'])
        db = connection[SETTINGS['MONGODB_DB']]
        
        self.githubCollection = db[SETTINGS['MONGODB_GITHUB_COLLECTION']]
        self.githubCollection.ensure_index([('ID', pymongo.ASCENDING)], unique=True, dropDups=True)
        
    def process_item(self, item, spider):
        if isinstance(item, RepoItem):
            dbItem = self.githubCollection.find_one({'ID': item['ID']})
            if dbItem:
                pass # simply skip existing items
                ### or you can update the tweet, if you don't want to skip:
                # dbItem.update(dict(item))
                # self.tweetCollection.save(dbItem)
                # logger.info("Update tweet:%s"%dbItem['url'])
                dbItem.update(dict(item))
                self.githubCollection.save(dbItem)
                logger.info("Update github:%s"%dbItem['html_url'])
            else:
                # 后加内容
                # userAddressItem = self.tweetCollection.find_one({'user_id': item['user_id'], 'btc_address': item['btc_address']})
                # if userAddressItem:
                #     pass
                # else:
                self.githubCollection.insert_one(dict(item))
                logger.debug("Add github:%s" %item['html_url'])

class SaveToFilePipeline(object):
    ''' pipeline that save data to disk '''
    def __init__(self):
        self.saveGithubInfoPath = SETTINGS['SAVE_GITHUB_INFO_PATH']
        mkdirs(self.saveGithubInfoPath) # ensure the path exists
        self.savePath = os.path.join(self.saveGithubInfoPath, 'info.json')
        self.file = open(self.savePath, 'wb')
        self.exporter = JsonItemExporter(self.file, encoding="utf-8", ensure_ascii=False)
        self.exporter.start_exporting()
    
    def process_item(self, item, spider):
        if isinstance(item, RepoItem):
            self.exporter.export_item(item) 
        else:
            logger.info("Item type is not recognized! type = %s" %type(item))

    def close_spider(self, spider): 
        self.exporter.finish_exporting() 
        self.file.close()


