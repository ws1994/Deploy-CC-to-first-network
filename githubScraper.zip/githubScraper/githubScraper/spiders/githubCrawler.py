'''
@Author: Netzhang
@Descripttion: 
@version: 
@Date: 2020-08-02 19:36:50
LastEditors: Netzhang
LastEditTime: 2020-08-05 07:38:16
'''

# -*- coding: utf-8 -*-
import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy import http
from scrapy.shell import inspect_response  # for debugging
import re
import json
import time
import logging
try:
    from urllib import quote  # Python 2.X
except ImportError:
    from urllib.parse import quote  # Python 3+

from githubScraper.items import RepoItem
from githubScraper.utils import get_month_list

logger = logging.getLogger(__name__)

class GithubScraper(CrawlSpider):
    name = 'GithubScraper'
    allowed_domains = ['github.com']

    def __init__(self, keyword='', *args, **kwargs):
        self.keyword = keyword
        self.sort = 'best-match'

        start_date = '2013-01-01'
        end_date = '2020-08-05'
        self.createdList = get_month_list(start_date, end_date)
        self.monthCount = len(self.createdList)
        self.currentId = 0
        # 时间规划排序
        # self.langs = ['javascript']
        # self.sorts = ['updated', 'best-match']

    def start_requests(self):
        self.currentMonth = self.createdList[self.currentId]

        url = f'https://api.github.com/search/repositories?&q={self.keyword}+created:{self.currentMonth}&per_page=100'
        yield http.Request(url=url, callback=self.parse)

    def get_next_link_url(self, response):
        if 'link' in response.headers:
            link = response.headers.get('link').decode('utf-8')    
            m = re.search(fr'.*<(https://api\.github\.com/search/repositories\?.+?)>; rel="next"',
                        link)
            if m is not None:
                print("下一页:{}".format(m.group(1)))
                return m.group(1)

        if self.currentId + 1 < self.monthCount:
            self.currentId += 1
            self.currentMonth = self.createdList[self.currentId]
            url = f'https://api.github.com/search/repositories?&q={self.keyword}+created:{self.currentMonth}&per_page=100'
            print(url)
            return url
        
        return None

    def parse(self, response):
        try:
            data = json.loads(response.body.decode("utf-8"))
            print("长度{}".format(len(data.get('items'))))
            for d in data.get('items'):
                yield RepoItem(
                ID=d.get('id'),
                name=d.get('name'),
                owner_name = d.get('owner').get('login'),
                full_name=d.get('full_name'),
                html_url=d.get('html_url'),
                description=d.get('description'),
                git_url=d.get('git_url'),
                ssh_url=d.get('ssh_url'),
                stars=d.get('stargazers_count'),
                forks=d.get('forks'),
                watchers=d.get('watchers_count'),
                created_at=d.get('created_at'),
                updated_at=d.get('updated_at'),
                pushed_at=d.get('pushed_at'),
                default_branch=d.get('default_branch'),

                size = d.get('size'),
                language=d.get('language'),
                )
                
            next_url = self.get_next_link_url(response)
            if next_url is not None:
                yield http.Request(url=next_url, callback=self.parse)
        except:
                logger.error("Error github")