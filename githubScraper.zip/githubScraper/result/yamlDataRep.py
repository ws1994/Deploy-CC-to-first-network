'''
Author: Netzhang
Descripttion: 用于发现hyperledger项目是否使用了private data
version: 
Date: 2020-08-05 00:54:41
LastEditors: Netzhang
LastEditTime: 2020-08-08 14:21:07
'''
import sys
sys.path.append("..")

import concurrent
from concurrent.futures import ThreadPoolExecutor
import os
import re
import pymongo
from utils.myLog import *
from githubScraper.settings import *
from pathlib import Path
import yaml

Logger = MyLog(filename="../log/yaml_explicit_judge.log",
               loggerName=__name__).getlog()

class PrivateCheckPipeline:
    def __init__(self, rows):
        if MONGODB_USER != '' and MONGODB_USER != None:
            url = 'mongodb://{}:{}@{}:{}/'.format(
                MONGODB_USER, MONGODB_PWD, MONGODB_SERVER, MONGODB_PORT)
            self.connection = pymongo.MongoClient(url)
        else:
            self.connection = pymongo.MongoClient(MONGODB_SERVER, MONGODB_PORT)
        self.db = self.connection[MONGODB_DB]
        self.githubCollection = self.db[MONGODB_GITHUB_COLLECTION]
        self.githubCollection.ensure_index(
            [('ID', pymongo.ASCENDING)], unique=True, dropDups=True)
        self.explicitPrivitCollection = self.db[MONGODB_EXPLICIT_PRIVATE_COLLECTION]
        
        self.explicitPrivitCollection.ensure_index(
            [('ID', pymongo.ASCENDING)], unique=False, dropDups=True)
        self.explicitPrivitCollection.ensure_index(
            [('html_url', pymongo.ASCENDING)], unique=False, dropDups=True)

        self.rows = rows

    def check(self, line):
        query = {"_id": line['_id']}
        # 1. 获取项目存放路径
        root_dir = Path(line["save_path"])
        fileType = '**/configtx.yaml'

        all_file = list(root_dir.glob(fileType))

        yaml_path = []
        
        for file in all_file:
            fileName = str(file)
            yaml_path.extend(fileName)
            try:
                with open(fileName,'r',encoding='utf-8') as f:
                    Application = False
                    Endorsement = False
                    EndorsementType = ""
                    EndorsementRule = ""
                    res = yaml.load(f,Loader=yaml.FullLoader)
                    if "Application" in res:
                        Application = True
                        if "Policies" in res["Application"]:
                            if "Endorsement" in res["Application"]["Policies"]:
                                Endorsement = True
                                if "Type" in res["Application"]["Policies"]["Endorsement"]:
                                    EndorsementType = res["Application"]["Policies"]["Endorsement"]["Type"]
                                if "Rule" in res["Application"]["Policies"]["Endorsement"]:
                                    EndorsementRule = res["Application"]["Policies"]["Endorsement"]["Rule"]
                                self.githubCollection.update_one({"ID": line["ID"]},{"$set": {"Endorsement": True}})
                                Logger.info(fileName)
                    # 写入新的表中
                    new_item = {"ID":line["ID"], "html_url":line["html_url"], "Endorsement": Endorsement, "Type":EndorsementType, "Rule":EndorsementRule, "file_path": fileName}
                    self.explicitPrivitCollection.insert_one(new_item)
            except:
                pass
        # try:
        #     # 4. 更新数据库
        #     if len(yaml_path) > 0:
        #             new_values = {"$set": {"yaml_config": True, "Endorsement": True, "Endorsement": ",".join(bad_file_list)}}
        #         else:
        #             new_values = {"$set": {"json_private": True, "json_private_path": ",".join(
        #                 private_file_list), "explicit_use": False}}
        #     else:
        #         new_values = {"$set": {"json_private": False}}
        #     self.githubCollection.update_one(query, new_values)
        # except Exception as e:
        #     Logger.info("数据库更新异常，错误信息：{}".format(e))
        #     return False
        return True

    def run(self):
        # 3. 多线程处理每条记录
        count = 0
        with ThreadPoolExecutor(max_workers=24) as executor:
            # 后续操作
            task_list = [executor.submit(self.check, line)
                         for line in self.rows]
            # 使用 future.result 获取函数结果
            for item in concurrent.futures.as_completed(task_list):
                count += 1
                if count % 50 == 0:
                    Logger.info("已检查项目数：{}".format(count))
        Logger.info("{}项目检查完成！！！".format(count))
        self.connection.close()


if __name__ == "__main__":
    if MONGODB_USER != '' and MONGODB_USER != None:
        url = 'mongodb://{}:{}@{}:{}/'.format(MONGODB_USER,
                                              MONGODB_PWD, MONGODB_SERVER, MONGODB_PORT)
        connection = pymongo.MongoClient(url)
    else:
        connection = pymongo.MongoClient(MONGODB_SERVER, MONGODB_PORT)
    db = connection[MONGODB_DB]

    githubCollection = db[MONGODB_GITHUB_COLLECTION]

    # 2. 读取数据并对数据
    rows = list(githubCollection.find(
        {"json_private": True, "explicit_use": False}).sort([('_id', 1)]))

    # print(len(rows))
    Logger.info("需要处理项目数：{}".format(len(rows)))
    repCheck = PrivateCheckPipeline(rows)
    repCheck.run()
