'''
Author: Netzhang
Descripttion: 用于发现hyperledger项目是否使用了private data
version: 
Date: 2020-08-05 00:54:41
LastEditors: Netzhang
LastEditTime: 2020-08-05 08:22:35
'''
import sys
sys.path.append("..")

from pathlib import Path
from githubScraper.settings import *
from utils.myLog import *
import pymongo
import re
import os
from concurrent.futures import ThreadPoolExecutor
import concurrent

Logger = MyLog(filename="../log/json_private_judge.log",
               loggerName=__name__).getlog()

class PrivateCheckPipeline:
    def __init__(self, rows):
        if MONGODB_USER != '' and MONGODB_USER != None:
            url = 'mongodb://{}:{}@{}:{}/'.format(
                MONGODB_USER, MONGODB_PWD, MONGODB_SERVER, MONGODB_PORT)
            self.connection = pymongo.MongoClient(url)
        else:
            self.connection = pymongo.MongoClient(MONGODB_SERVER, MONGODB_PORT)
        self.db = self.connection[MONGODB_DB]
        self.githubCollection = self.db[MONGODB_GITHUB_COLLECTION]
        self.githubCollection.ensure_index(
            [('ID', pymongo.ASCENDING)], unique=True, dropDups=True)

        self.rows = rows

    def check(self, line):
        query = {"_id": line['_id']}
        # 1. 获取项目存放路径
        root_dir = Path(line["save_path"])
        fileType = '**/*.json'
        # 2. 查询到所有满足后缀格式的文件路径
        # for root, dirs, files in os.walk(root_dir):
        #     for name in files:
        #         if name.endswith((".json")):
        #             print(name)

        all_file = list(root_dir.glob(fileType))
        private_file_list = []
        bad_file_list = []
        # 3. 读取文件，判断是否使用了private data
        for file in all_file:
            fileName = str(file)
            # if fileName.find("collections_config.json") != -1 :
            #     Logger.info(fileName)
            keyList = ["\"name\"", "\"policy\"", "\"requiredPeerCount\"",
                       "\"maxPeerCount\"", "\"blockToLive\"", "\"memberOnlyRead\""]
            badKey = ["endorsementPolicy"]
            # f.close()
            try:
                with open(fileName, 'r', encoding="utf-8") as f:
                    lines = f.readlines()
                    # 判断是否是private date
                    for line in lines:
                        # if len(keyList) == 0:
                        #     break
                        for key in keyList:
                            if line.find(key) != -1:
                                keyList.remove(key)

                        # 判断特别的模式
                        for key in badKey:
                            if line.find(key) != -1:
                                badKey.remove(key)

                    if len(keyList) < 2:
                        Logger.info(fileName)
                        private_file_list.append(fileName)
                        if len(badKey) == 0:
                            bad_file_list.append(fileName)

            except Exception as e:
                Logger.info("文件处理异常：{}，错误信息：{}".format(fileName, e))
                return False

        try:
            # 4. 更新数据库
            if len(private_file_list) > 0:
                if len(bad_file_list) > 0:
                    new_values = {"$set": {"json_private": True, "json_private_path": ",".join(
                        private_file_list), "explicit_use": True, "explicit_path": ",".join(bad_file_list)}}
                else:
                    new_values = {"$set": {"json_private": True, "json_private_path": ",".join(
                        private_file_list), "explicit_use": False}}
            else:
                new_values = {"$set": {"json_private": False}}
            self.githubCollection.update_one(query, new_values)
        except Exception as e:
            Logger.info("数据库更新异常，错误信息：{}".format(e))
            return False
        return True

    def run(self):
        # 3. 多线程处理每条记录
        count = 0
        with ThreadPoolExecutor(max_workers=24) as executor:
            # 后续操作
            task_list = [executor.submit(self.check, line)
                         for line in self.rows]
            # 使用 future.result 获取函数结果
            for item in concurrent.futures.as_completed(task_list):
                count += 1
                if count % 50 == 0:
                    Logger.info("已检查项目数：{}".format(count))
        Logger.info("{}项目检查完成！！！".format(count))
        self.connection.close()


if __name__ == "__main__":
    if MONGODB_USER != '' and MONGODB_USER != None:
        url = 'mongodb://{}:{}@{}:{}/'.format(MONGODB_USER,
                                              MONGODB_PWD, MONGODB_SERVER, MONGODB_PORT)
        connection = pymongo.MongoClient(url)
    else:
        connection = pymongo.MongoClient(MONGODB_SERVER, MONGODB_PORT)
    db = connection[MONGODB_DB]

    githubCollection = db[MONGODB_GITHUB_COLLECTION]

    # 2. 读取数据并对数据
    rows = list(githubCollection.find(
        {"is_download": True}).sort([('_id', 1)]))

    Logger.info("需要处理项目数：{}".format(len(rows)))
    repCheck = PrivateCheckPipeline(rows)
    repCheck.run()
