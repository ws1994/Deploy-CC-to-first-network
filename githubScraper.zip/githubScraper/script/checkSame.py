'''
Author: Netzhang
Descripttion: 
version: 
Date: 2020-08-06 15:01:57
LastEditors: Netzhang
LastEditTime: 2020-08-16 00:32:25
'''
import sys
sys.path.append("..")

from githubScraper.settings import *
import os
import pymongo
import re
import json

from bson import json_util

if __name__ == "__main__":
    if MONGODB_USER != '' and MONGODB_USER != None:
        url = 'mongodb://{}:{}@{}:{}/'.format(MONGODB_USER,
                                              MONGODB_PWD, MONGODB_SERVER, MONGODB_PORT)
        connection = pymongo.MongoClient(url)
    else:
        connection = pymongo.MongoClient(MONGODB_SERVER, MONGODB_PORT)
    db = connection[MONGODB_DB]

    githubCollection = db[MONGODB_GITHUB_COLLECTION]
    githubFabricCollection = db[MONGODB_GITHUB_FABRIC_COLLECTION]

    # fabricRows = list(githubFabricCollection.find({"updated_at": { "$gte": "2016-01-01" }}).sort([('_id', 1)]))
    # githubRows = list(githubCollection.find({"updated_at": { "$gte": "2016-01-01" }}).sort([('_id', 1)]))

    # explicit_condition = { "updated_at": { "$gte": "2016-01-01" }, "json_private": True}
    # explicitGithubPrivateRows = list(githubCollection.find(explicit_condition))
    # implicit_condition = { "updated_at": { "$gte": "2016-01-01" }, "$or":[{"implicit_use": True}]}
    # implicitGithubPrivateRows = list(githubCollection.find(implicit_condition)) 

    # condition = { "updated_at": { "$gte": "2016-01-01" }, "$or":[{"json_private": True},{"go_private": True},{"java_private": True},{"node_private": True}]}
    # githubPrivateRows = list(githubCollection.find(condition))

    # # 1. 
    # stars = 0
    # endorStars = 0
    # for line in explicitGithubPrivateRows:
    #     stars += line["stars"]
    #     if line["explicit_use"] == True:
    #         print("html_url:{},stars:{}".format(line["html_url"],line["stars"]))
    #         endorStars += line["stars"]
    # print("github_info检测到有：{}个项目使用了explicit private data! stars:{}, 其中endorsement policy的stars:{}".format(len(explicitGithubPrivateRows),stars,endorStars))
        
    # stars = 0
    # for line in implicitGithubPrivateRows:
    #     stars += line["stars"]
    # print("github_info检测到有：{}个项目使用了implicit private data! stars:{}".format(len(implicitGithubPrivateRows),stars))

    # stars = 0
    # for line in githubPrivateRows:
    #     stars += line["stars"]
    # print("github_info检测到有：{}个项目使用了private data! stars:{}".format(len(githubPrivateRows),stars))
    
    # sameRepCount = 0
    # for line in implicitGithubPrivateRows:
    #     if githubCollection.find_one({"ID": line["ID"]})["json_private"]:
    #         sameRepCount += 1
    
    # print("github_info检测到有：{}个项目explicit implicit重复项目".format(sameRepCount))
    
    # # 2. 
    # res = []
    # for line in fabricRows:
    #     if githubCollection.find_one({"ID": line["ID"]}) == None:
    #         res.append(line)
    # print("github_info_fabric中有：{}个项目github_info_fabric没有".format(len(res)))

    # # 3. 
    # res = []    
    # for line in githubPrivateRows:
    #     if githubFabricCollection.find_one({"ID": line["ID"]}) == None:
    #         res.append(line)

    # print("github_info检测到：{}个使用private data项目中，有{}个未出现在github_info_fabric!!!".format(len(githubPrivateRows),len(res)))

    # # 4. 
    # githubStarCount = 0
    # for line in githubRows:
    #     githubStarCount += line["stars"]
    # fabricStarCount = 0
    # for line in fabricRows:
    #     fabricStarCount += line["stars"]
    # print("hyperledger项目stars总和：{}".format(githubStarCount))
    # print("hyperledger fabric项目stars总和：{}".format(fabricStarCount))


    # dateCondition1 = { "updated_at": { "$gte": "2016-01-01", "$lte": "2016-12-31"}, "$or":[{"json_private": True},{"go_private": True},{"java_private": True},{"node_private": True}]}
    dateCondition1 = { "updated_at": { "$gte": "2016-01-01", "$lte": "2016-12-31"}, "json_private": True}
    dateCondition2 = { "updated_at": { "$gte": "2016-01-01", "$lte": "2016-12-31"}}
    print("2016:")
    print(len(list(githubCollection.find(dateCondition2))))
    print(len(list(githubCollection.find(dateCondition1))))
    print(len(list(githubCollection.find(dateCondition2))) - len(list(githubCollection.find(dateCondition1))))
    # dateCondition1 = { "updated_at": { "$gt": "2016-12-31", "$lte": "2017-12-31"}, "$or":[{"json_private": True},{"go_private": True},{"java_private": True},{"node_private": True}]}
    dateCondition1 = { "updated_at": { "$gt": "2016-12-31", "$lte": "2017-12-31"}, "json_private": True}
    dateCondition2 = { "updated_at": { "$gt": "2016-12-31", "$lte": "2017-12-31"}}
    print("2017:")
    print(len(list(githubCollection.find(dateCondition2))))
    print(len(list(githubCollection.find(dateCondition1))))
    print(len(list(githubCollection.find(dateCondition2))) - len(list(githubCollection.find(dateCondition1))))
    # dateCondition1 = { "updated_at": { "$gt": "2017-12-31", "$lte": "2018-12-31"}, "$or":[{"json_private": True},{"go_private": True},{"java_private": True},{"node_private": True}]}
    dateCondition1 = { "updated_at": { "$gt": "2017-12-31", "$lte": "2018-12-31"}, "json_private": True}
    dateCondition2 = { "updated_at": { "$gt": "2017-12-31", "$lte": "2018-12-31"}}
    print("2018:")
    print(len(list(githubCollection.find(dateCondition2))))
    print(len(list(githubCollection.find(dateCondition1))))
    print(len(list(githubCollection.find(dateCondition2))) - len(list(githubCollection.find(dateCondition1))))
    # dateCondition1 = { "updated_at": { "$gt": "2018-12-31", "$lte": "2019-12-31"}, "$or":[{"json_private": True},{"go_private": True},{"java_private": True},{"node_private": True}]}
    dateCondition1 = { "updated_at": { "$gt": "2018-12-31", "$lte": "2019-12-31"}, "json_private": True}
    dateCondition2 = { "updated_at": { "$gt": "2018-12-31", "$lte": "2019-12-31"}}
    print("2019:")
    print(len(list(githubCollection.find(dateCondition2))))
    print(len(list(githubCollection.find(dateCondition1))))
    print(len(list(githubCollection.find(dateCondition2))) - len(list(githubCollection.find(dateCondition1))))
    # dateCondition1 = { "updated_at": { "$gt": "2019-12-31", "$lte": "2020-12-31"}, "$or":[{"json_private": True},{"go_private": True},{"java_private": True},{"node_private": True}]}
    dateCondition1 = { "updated_at": { "$gt": "2019-12-31", "$lte": "2020-12-31"}, "json_private": True}
    dateCondition2 = { "updated_at": { "$gt": "2019-12-31", "$lte": "2020-12-31"}}
    print("2020:")
    print(len(list(githubCollection.find(dateCondition2))))
    print(len(list(githubCollection.find(dateCondition1))))
    print(len(list(githubCollection.find(dateCondition2))) - len(list(githubCollection.find(dateCondition1))))

    # explicitCondition = { "updated_at": { "$gte": "2016-01-01" }, "json_private": True}
    # rows1 = list(githubCollection.find(explicitCondition))
    # stars1 = 0
    # for line in rows1:
    #     stars1 += line["stars"]
    # print(len(rows1))
    
    # implicitCondition = { "updated_at": { "$gte": "2016-01-01" }, "implicit_use": True}
    # rows2 = list(githubCollection.find(implicitCondition))
    # stars2 = 0
    # for line in rows2:
    #     stars2 += line["stars"]
    # print(len(rows2))

    # bothCondition = { "updated_at": { "$gte": "2016-01-01" }, "implicit_use": True, "json_private": True}
    # rows3 = list(githubCollection.find(bothCondition))
    # stars3 = 0
    # for line in rows3:
    #     stars3 += line["stars"]
    # print(len(rows3))

    # print(stars1 - stars3)
    # print(stars3)
    # print(stars2 - stars3)

    # condition = { "updated_at": { "$gte": "2016-01-01" }}
    # rows4 = list(githubCollection.find(condition))
    # stars4 = 0
    # for line in rows4:
    #     stars4 += line["stars"]

    # print(len(rows4))
    # print(stars4)
    # print(stars4 - stars1 - stars2 + stars3)
