'''
Author: Netzhang
Descripttion: 
version: 
Date: 2020-08-03 03:26:31
LastEditors: Netzhang
LastEditTime: 2020-08-04 22:57:16
'''
import sys
sys.path.append("..")

import datetime
import os
import re
import time
import requests
import zipfile
import json
from threading import Thread
from multiprocessing import Queue
from bs4 import BeautifulSoup


class Code_spider(object):
    def __init__(self):
        self.folder = '../data/repo/'  # 项目存放目录（需修改）
        self.headers = {'User-Agent': 'Mozilla/5.0'}
        self.urlCount = 0
        # self.q1 = Queue()  # 创建消息队列，存放项目主页的链接
        self.q2 = Queue()  # 创建消息队列，存放下载链接和对应项目名

        # 根据方法名称启动线程
    def work(self, methode_name):
        L = []
        for i in range(8):
            if methode_name == 'down_load':
                th = Thread(target=self.down_load, args=(i + 1,))
                th.start()
                L.append(th)
            else:
                exit('方法名称有误，线程终止')
        for th in L:
            th.join()

    def get_DownUrl(self, infoPath):
        if os.path.exists(infoPath):
            try:
                with open(infoPath, 'r', encoding='utf8')as fp:
                    json_data = json.load(fp)
                for item in json_data:
                    print(item["full_name"])
                    tmp = item["full_name"].split('/')
                    linkAndFilename = [
                        tmp[0], tmp[1], "https://codeload.github.com/{}/{}/zip/master".format(tmp[0], tmp[1])]
                    self.q2.put(linkAndFilename)
                    self.urlCount += 1
                print('共需下载{}个链接'.format(self.urlCount))
                return True
            except Exception as e:
                print("读取文件异常")
                return False
        else:
            print('github项目信息不存在！')
            return False

    # 多线程循环执行的下载函数
    def down_load(self, n):
        while True:
            try:
                linkAndFilename = self.q2.get(block=True, timeout=2)
                user = linkAndFilename[0]
                filename = user+" "+linkAndFilename[1]
                link = linkAndFilename[2]
            except:
                print('取不到链接了,%s号线程结束工作' % n)
                break
            # 文件的绝对路径
            abs_filename = self.folder + filename + '.zip'
            # 只下载本地不存在或文件大小为0的链接
            if (not os.path.exists(abs_filename)) or os.path.getsize(abs_filename) == 0:
                # 1. 下载zip文件
                with open(abs_filename, 'wb') as code:
                    print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "线程%s开始下载：%s\n" % (n, filename),
                          end='')
                    # 若网络情况的变化导致异常，则3s后重新请求，一直循环，直到访问站点成功
                    while True:
                        try:
                            r = requests.get(link,stream=True)
                            # code.write(requests.get(
                            #     link, self.headers).content)
                            for chunk in r.iter_content(chunk_size=1024): #边下载边存硬盘
                                if chunk:
                                    code.write(chunk)
                            break
                        except:
                            print('%s号线程网络请求发生异常，尝试重新下载...' % n)
                            time.sleep(3)
                    self.urlCount -= 1
                    print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "线程%s完成下载：%s,共剩余%s个项目正在下载\n" % (
                        n, filename, self.urlCount), end='')
                # # 2. 解压zip文件
                # with zipfile.ZipFile(abs_filename, 'r') as f:
                #     f.extractall(self.folder+'.')
                # # 3. 删除zip文件
                # os.remove(abs_filename)
            else:
                self.urlCount -= 1
                print('%s文件已存在，无需下载，共剩余%s个项目正在下载\n' %
                      (abs_filename, self.urlCount), end='')
            
            time.sleep(2)

if __name__ == '__main__':
    start_time = time.time()

    spider = Code_spider()

    # 读取文件或数据库，获取所有github项目的链接
    infoPath = "../data/info.json"
    # data = ["dhgdhg", "github-downloader", "https://codeload.github.com/dhgdhg/github-downloader/zip/master"]
    # spider.q2.put(data)
    # spider.work('down_load')
    # end_time = time.time()
    # print("下载总时间:", end_time - start_time)
    if spider.get_DownUrl(infoPath):
        print('开始下载文件...')
        spider.work('down_load')
        end_time = time.time()
        print("下载总时间:", end_time - start_time)