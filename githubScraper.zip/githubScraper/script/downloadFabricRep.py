'''
Author: Netzhang
Descripttion: 
version: 
Date: 2020-08-04 22:49:19
LastEditors: Netzhang
LastEditTime: 2020-08-06 20:32:11
'''
import sys
sys.path.append("..")

import zipfile
import requests
from githubScraper.settings import *
from utils.myLog import *
import os
import pymongo
import re
from concurrent.futures import ThreadPoolExecutor
import concurrent


Logger = MyLog(filename="../log/github_fabric_rep_download.log",
               loggerName=__name__).getlog()

class DownloadGithubPipeline:
    def __init__(self, rows):
        if MONGODB_USER != '' and MONGODB_USER != None:
            url = 'mongodb://{}:{}@{}:{}/'.format(
                MONGODB_USER, MONGODB_PWD, MONGODB_SERVER, MONGODB_PORT)
            self.connection = pymongo.MongoClient(url)
        else:
            self.connection = pymongo.MongoClient(MONGODB_SERVER, MONGODB_PORT)
        self.db = self.connection[MONGODB_DB]
        self.githubCollection = self.db[MONGODB_GITHUB_COLLECTION]
        self.githubFabricCollection = self.db[MONGODB_GITHUB_FABRIC_COLLECTION]

        self.githubCollection.ensure_index(
            [('ID', pymongo.ASCENDING)], unique=True, dropDups=True)
        self.githubFabricCollection.ensure_index(
            [('ID', pymongo.ASCENDING)], unique=True, dropDups=True)

        self.rows = rows

        # 用于下载项目
        self.folder = '../data/repo/'  # 项目存放目录

    # 用于创建目录
    def mkdir(self, dirs):
        ''' Create `dirs` if not exist. '''
        if not os.path.exists(dirs):
            os.makedirs(dirs)

    def download(self, line):
        save_path = ""
        tmp = self.githubCollection.find_one({"ID": line["ID"]})
        if tmp == None:
            # 1. 获取用户和库名
            owner_name = line["owner_name"]
            rep_name = line["name"]
            default_branch = line["default_branch"]
            # 2. 创建作者目录，如果不存在则创建
            rep_dirs = self.folder + owner_name

            try:
                self.mkdir(rep_dirs)
                download_url = "https://codeload.github.com/{}/{}/zip/{}".format(
                    owner_name, rep_name, default_branch)

                filename = rep_dirs + "/" + rep_name + '.zip'

                # 删除之前下载不完整的文件
                if os.path.exists(filename):
                    os.remove(filename)
            except:
                Logger.error("文件：{}准备过程出错！！！".format(download_url))
                return False

            # 3. 下载文件
            with open(filename, 'wb') as code:
                retry_count = 1
                while retry_count <= 3:
                    try:
                        r = requests.get(download_url, stream=True)
                        for chunk in r.iter_content(chunk_size=1024):  # 边下载边存硬盘
                            if chunk:
                                code.write(chunk)
                        break
                    except:
                        if retry_count == 3:
                            Logger.error("文件：{}3次均未下载成功！！！".format(download_url))
                            return False
                        else:
                            Logger.error("下载{}失败第{}次！！！".format(
                                download_url, retry_count))
                            time.sleep(1)
                            retry_count += 1
            try:
                # 4. 解压文件
                save_path = rep_dirs + "/" + rep_name
                with zipfile.ZipFile(filename, 'r') as f:
                    self.mkdir(save_path)
                    f.extractall(save_path + "/" + '.')

                # 5. 删除zip压缩文件
                os.remove(filename)

            except:
                Logger.error("文件：{}解压过程出错！！！".format(download_url))
                return False
            # 如果成功，更新数据库
            Logger.info("项目:{},下载解压处理完成 ！！！".format(download_url))
            save_path = os.path.abspath(save_path)
        else:
            Logger.info("项目已存在:{}！".format(line["html_url"]))
            save_path = tmp["save_path"]
        query = {"_id": line["_id"]}
        new_values = {"$set": {"is_download": True, "save_path": save_path}}
        self.githubFabricCollection.update_one(query, new_values)
        return True

    def run(self):
        # 3. 多线程处理每条记录
        count = 0

        with ThreadPoolExecutor(max_workers = 24) as executor:
            # 后续操作
            task_list = [executor.submit(self.download, line)
                         for line in self.rows]
            # 使用 future.result 获取函数结果
            for item in concurrent.futures.as_completed(task_list):
                count += 1
                if count % 100 == 0:
                    Logger.info("已下载解压项目数：{}".format(count))
        Logger.info("{}项目下载解压完成！！！".format(count))
        self.connection.close()

if __name__ == "__main__":
    if MONGODB_USER != '' and MONGODB_USER != None:
        url = 'mongodb://{}:{}@{}:{}/'.format(MONGODB_USER,
                                              MONGODB_PWD, MONGODB_SERVER, MONGODB_PORT)
        connection = pymongo.MongoClient(url)
    else:
        connection = pymongo.MongoClient(MONGODB_SERVER, MONGODB_PORT)
    db = connection[MONGODB_DB]

    githubFabricCollection = db[MONGODB_GITHUB_FABRIC_COLLECTION]

    # 2. 读取数据并对数据
    rows = list(githubFabricCollection.find(
        {"is_download": False, "size": {"$gt": 0}}).sort([('_id', 1)]))

    Logger.info("需要处理数据量：{}".format(len(rows)))
    downloadGithub = DownloadGithubPipeline(rows)
    downloadGithub.run()